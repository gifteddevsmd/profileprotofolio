 ## Dave pairing site
 * QR code pair
 * 8 digit pair codes

